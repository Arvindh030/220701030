
import { useState } from 'react';
import './App.css';

function App() {
  const [originalUrl, setOriginalUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [error, setError] = useState("");
  const [analytics, setAnalytics] = useState({
    total: 0,
    recent: [] 
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setShortUrl("");
    if (!originalUrl) {
      setError("Please enter a URL.");
      return;
    }
    try {
      const response = await fetch(`https://api.shrtco.de/v2/shorten?url=${encodeURIComponent(originalUrl)}`);
      if (!response.ok) throw new Error("Network error");
      const data = await response.json();
      if (data.ok) {
        setShortUrl(data.result.full_short_link);
        setAnalytics(prev => {
          const newRecent = [
            { original: originalUrl, short: data.result.full_short_link, date: new Date().toLocaleString() },
            ...prev.recent
          ].slice(0, 5);
          return {
            total: prev.total + 1,
            recent: newRecent
          };
        });
        setOriginalUrl("");
      } else {
        throw new Error("API error");
      }
    } catch (err) {
      
      const mockShort = `https://short.url/${Math.random().toString(36).substring(2, 8)}`;
      setShortUrl(mockShort);
      setAnalytics(prev => {
        const newRecent = [
          { original: originalUrl, short: mockShort, date: new Date().toLocaleString() },
          ...prev.recent
        ].slice(0, 5);
        return {
          total: prev.total + 1,
          recent: newRecent
        };
      });
      setOriginalUrl("");
      setError("(Demo) API unreachable. Showing mock shortened URL.");
    }
  };

  return (
    <div className="url-shortener-container">
      <h2>URL Shortener</h2>
      <form onSubmit={handleSubmit} className="url-form">
        <input
          type="url"
          placeholder="Enter your URL here"
          value={originalUrl}
          onChange={e => setOriginalUrl(e.target.value)}
          required
        />
        <button type="submit">Shorten</button>
      </form>
      {shortUrl && (
        <div className="result">
          <p>Shortened URL: <a href={shortUrl} target="_blank" rel="noopener noreferrer">{shortUrl}</a></p>
        </div>
      )}
      {error && <p className="error">{error}</p>}

      <div className="analytics">
        <h3>Analytics</h3>
        <p><strong>Total URLs Shortened:</strong> {analytics.total}</p>
        {analytics.recent.length > 0 && (
          <div>
            <strong>Recent URLs:</strong>
            <ul className="recent-list">
              {analytics.recent.map((item, idx) => (
                <li key={idx}>
                  <span title={item.original}>{item.original.length > 40 ? item.original.slice(0, 40) + '...' : item.original}</span>
                  <br />
                  <a href={item.short} target="_blank" rel="noopener noreferrer">{item.short}</a>
                  <span className="date"> ({item.date})</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
