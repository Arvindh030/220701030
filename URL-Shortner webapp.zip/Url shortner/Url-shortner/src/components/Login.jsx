
function login(){
    OnButtonClick()
    {
        alert("Login successful")
    }
    return <div className="Loginpage">
        <form onSubmit={OnButtonClick} className="loginForm">
            <p>USERNAME</p>
            <input type="text" placeholder="Username" className="user"/>
            <p>Password</p>
            <input type="password" placeholder="pass" className="pw"/>
            <button type="submit" className="login" onClick={OnButtonClick}>LOGIN</button>
        </form>
    </div>
}

export default login